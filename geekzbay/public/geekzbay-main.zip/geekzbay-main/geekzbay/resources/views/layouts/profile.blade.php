@extends('layouts.template')
@section('title', 'Profile')
@section('main')
    Profile Page
@endsection