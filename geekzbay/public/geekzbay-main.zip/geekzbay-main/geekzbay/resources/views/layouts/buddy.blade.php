@extends('layouts.template')
@section('title', 'buddy')
@section('main')
    Buddy Page
@endsection