@extends('layouts.template')
@section('title', 'meetup')
@section('main')
    Meetup Page
@endsection