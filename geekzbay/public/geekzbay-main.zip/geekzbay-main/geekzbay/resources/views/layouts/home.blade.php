@extends('layouts.template')
@section('title', 'Home')
@section('main')
    Home Page
@endsection