@extends('layouts.template')
@section('title', 'community')
@section('main')
    Community Page
@endsection