@extends('layouts.template')
@section('title', 'locations')
@section('main')
    locations Page
@endsection