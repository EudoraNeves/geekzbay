@extends('layouts.template')
@section('title', 'My Buddies')
@section('main')
    My Buddies Page
@endsection