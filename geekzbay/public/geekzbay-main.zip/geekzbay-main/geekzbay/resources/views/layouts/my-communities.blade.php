@extends('layouts.template')
@section('title', 'My Communities')
@section('main')
    My Communities Page
@endsection