@extends('layouts.template')
@section('title', 'My Locations')
@section('main')
    My Locations Page
@endsection