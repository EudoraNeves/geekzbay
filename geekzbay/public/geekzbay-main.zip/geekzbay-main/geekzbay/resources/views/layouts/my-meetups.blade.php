@extends('layouts.template')
@section('title', 'My Meetups')
@section('main')
    My Meetups Page
@endsection